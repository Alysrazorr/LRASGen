import os

def find_default_handlers(str, project_path):
    matched_files = []

    # 遍历目录及子目录
    for root, dirs, files in os.walk(project_path):
        for file in files:
            # 只处理.py文件
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if str in content:
                            print(f'Found in: {file_path}')
                            matched_files.append(file_path)
                except Exception as e:
                    print(f'Error reading {file_path}: {e}')
    return matched_files