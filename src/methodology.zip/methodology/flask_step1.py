import os
import re


def find_python_files_in_directory(directory):
    """遍历目录，返回所有 Python 文件的路径列表"""
    py_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                py_files.append(os.path.join(root, file))
    return py_files


def find_imported_files(file_path, all_py_files):
    """查找给定文件中引用的全部 Python 文件"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.readlines()

    imports = set()
    import_pattern = re.compile(r'^(?:import|from)\s+([^\s]+)')

    for line in content:
        match = import_pattern.match(line)
        if match:
            module_name = match.group(1)
            # 将模块名称转换为适合文件路径匹配的格式
            # 例如：将'module.submodule'替换为'module/submodule'以便于查找
            module_path = module_name.replace('.', os.sep)

            # 检查所有 Python 文件是否包含模块路径
            matched_files = [f for f in all_py_files if
                             os.path.basename(f).startswith(module_name.split('.')[-1]) and module_path in f]
            imports.update(matched_files)

    return imports


def find_all_imported_files(start_file):
    """查找并返回所有导入的 Python 文件"""
    project_root = os.path.dirname(start_file)
    all_py_files = find_python_files_in_directory(project_root)
    return find_imported_files(start_file, all_py_files)


if __name__ == "__main__":
    urls_file = r"D:\Researches\ReSpecLLM\datasets\datasets\gramps-web-api-master\gramps_webapi\api\__init__.py"  # 替换为你的 urls.py 路径
    import_paths = find_all_imported_files(urls_file)

    print("导入的文件路径：")
    for path in import_paths:
        print(path)
