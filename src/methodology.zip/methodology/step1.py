import os
import re


def main(directory, framework):
    matched_files = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(framework["suffix"]):
                file_path = "\\\\?\\" + str(os.path.join(root, file))
                with open(file_path, "r", encoding="utf-8", errors='replace') as f:
                    content = f.read()
                    if any(re.compile(regex).search(content) for regex in framework["regex"]):
                        matched_files.append(file_path)

    return matched_files
