import os
import re

from methodology import django_step1, flask_step1, tornado_utils, webpy_utils, csharp_step1


def main(project):
    matched_files = []
    directory = project['root_path']
    framework = project['framework']
    # print(directory)
    # print(framework)
    # print(configuration_file)

    if framework["name"] == 'Django':
        configuration_file = project['configuration_file']
        a = django_step1.main(configuration_file)
        return a

    if framework["name"] == 'Flask':
        configuration_file = project['configuration_file']
        a = flask_step1.find_all_imported_files(configuration_file)
        print(a)
        return a


    if framework["name"] == 'Tornado':
        keyword = project['keyword']
        a = tornado_utils.find_default_handlers(keyword, directory)
        print(a)
        return a

    if framework["name"] == 'Web Py':
        configuration_file = project['configuration_file']
        urls = project['urls']
        print(urls)
        a = webpy_utils.find_controller_files(urls, directory)
        print(a)
        return a

    if framework["name"] == 'ASP DoNet Core':
        a = csharp_step1.find_http_endpoints(directory)
        print(a)
        return a

    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(framework["suffix"]):
                file_path = "\\\\?\\" + str(os.path.join(root, file))
                with open(file_path, "r", encoding="utf-8", errors='replace') as f:
                    content = f.read()
                    if any(re.compile(regex).search(content) for regex in framework["regex"]):
                        matched_files.append(file_path)

    return matched_files
