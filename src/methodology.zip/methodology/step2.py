import re
from pathlib import Path

from methodology import django_step2, csharp_step2


def get_project_classes(directory, extension):
    """
    递归获取文件夹下所有指定后缀的文件路径
    :param directory: 目标文件夹路径
    :param extension: 文件后缀（例如：'.txt', '.jpg'）
    :return: 符合条件的文件路径列表
    """
    # 确保后缀以点开头（例如 '.txt' 而不是 'txt'）
    if not extension.startswith('.'):
        extension = f'.{extension}'

    # 使用 rglob 递归查找所有文件，并过滤后缀
    files = []
    for file in [str(file) for file in Path(directory).rglob('*') if file.is_file() and file.suffix == extension]:
        files.append(file[:-5].replace('\\', '.'))
    return files


def extract_imports_from_file(file_path):
    # file_path = "\\\\?\\" + file_path
    """从文件中读取代码并提取 import 语句"""
    with open(file_path, 'r', encoding='utf-8', errors='replace') as file:  # 打开文件，指定编码为 UTF-8
        code = file.read()  # 读取文件内容
    # 正则表达式匹配 import 语句
    pattern = r'import\s+(?:static\s+)?([\w\.\*]+);'
    imports = re.findall(pattern, code)  # 提取所有匹配的 import 语句
    return imports


def get_actual_imports(a, b):
    """
    判断字符串 A 是否被包含在数组 B 的某条字符串中，
    并将符合条件的字符串放入数组 D 中返回。
    :param a: 要查找的字符串
    :param b: 字符串数组（列表）
    :return: 包含符合条件的字符串的数组 D
    """
    xs = []

    for imp in a:
        for file in b:
            if imp in file:
                xs.append(file.replace('.', '\\') + '.java')
                break
    return xs


def get_actual_imports_nested(java_path, files, all_imports, processed_files=None):
    if processed_files is None:
        processed_files = set()

    # 如果文件已经处理过，直接返回
    if java_path in processed_files:
        return

    # 标记文件为已处理
    processed_files.add(java_path)

    imports = extract_imports_from_file(java_path)
    actual_imports = get_actual_imports(imports, files)

    if len(actual_imports) == 0:
        return
    else:
        for imp in actual_imports:
            get_actual_imports_nested(imp, files, all_imports, processed_files)

    all_imports.extend(actual_imports)


def read_and_clean_codes(java_file_path, remove_empty_lines=True):
    with open(java_file_path, 'r', encoding='utf-8', errors='replace') as file:
        lines = file.readlines()

    cleaned_lines = []
    skip = True  # 初始跳过状态
    for line in lines:
        stripped_line = line.strip()  # 去掉换行符和前后空白字符

        # 如果处于跳过状态，并且是 package 或 import 行，则跳过
        if skip and (stripped_line.startswith('package') or stripped_line.startswith('import')):
            continue
        # 如果是注释行，保持跳过状态
        elif skip and stripped_line.startswith(('//', '/*', '*')):
            continue
        # 如果遇到非空行且不是 package、import 或注释，则停止跳过
        elif stripped_line and not stripped_line.startswith(('//', '/*', '*')):
            skip = False
            cleaned_lines.append(line)  # 保留非空行
        # 如果是空行，根据 remove_empty_lines 参数决定是否保留
        elif not remove_empty_lines:
            cleaned_lines.append(line)  # 保留空行

    # 拼接结果
    cleaned_code = ''.join(cleaned_lines)
    return cleaned_code


def main(endpoint_entry_file_paths, project):
    directory = project['root_path']
    framework = project['framework']
    endpoint_codes_map = {}

    if framework['name'] == 'Django':
        for endpoint_entry_file_path in endpoint_entry_file_paths:
            # print(endpoint_entry_file_path)
            x = django_step2.main(directory, endpoint_entry_file_path)
            endpoint_lines = {
                "entry_code_file": django_step2.remove_imports_and_return_content(endpoint_entry_file_path)
            }

            for y1 in x:
                endpoint_lines[y1] = django_step2.remove_imports_and_return_content(y1)

            endpoint_codes_map[endpoint_entry_file_path] = endpoint_lines

        # print(endpoint_codes_map)
        return endpoint_codes_map

    if framework['name'] == 'Web Py':
        for endpoint_entry_file_path in endpoint_entry_file_paths:
            # print(endpoint_entry_file_path)
            x = django_step2.main(directory, endpoint_entry_file_path)
            endpoint_lines = {
                "entry_code_file": django_step2.remove_imports_and_return_content(endpoint_entry_file_path),
                "urls_file": django_step2.remove_imports_and_return_content(project["configuration_file"]),
            }

            for y1 in x:
                endpoint_lines[y1] = django_step2.remove_imports_and_return_content(y1)

            endpoint_codes_map[endpoint_entry_file_path] = endpoint_lines

        # print(endpoint_codes_map)
        return endpoint_codes_map

    if framework['name'] == 'ASP DoNet Core':
        for endpoint_entry_file_path in endpoint_entry_file_paths:
            # print(endpoint_entry_file_path)
            x = csharp_step2.main(directory, endpoint_entry_file_path)
            endpoint_lines = {
                "entry_code_file": csharp_step2.read_without_using_lines(endpoint_entry_file_path)
            }

            for y1 in x:
                endpoint_lines[y1] = csharp_step2.read_without_using_lines(y1)

            endpoint_codes_map[endpoint_entry_file_path] = endpoint_lines

        # print(endpoint_codes_map)
        return endpoint_codes_map

    files = get_project_classes(directory, ".java")

    for endpoint_entry_file_path in endpoint_entry_file_paths:
        all_imports = []
        get_actual_imports_nested(endpoint_entry_file_path, files, all_imports)
        x = list(set(all_imports))

        endpoint_lines = {
            "entry_code_file": read_and_clean_codes(endpoint_entry_file_path)
        }

        for y1 in x:
            endpoint_lines[y1] = read_and_clean_codes(y1)

        endpoint_codes_map[endpoint_entry_file_path] = endpoint_lines
    return endpoint_codes_map
