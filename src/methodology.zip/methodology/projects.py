import os

spring_boot = {
    "language": "java",
    "name": "Spring Boot",
    "suffix": ".java",
    "regex": [
        r"@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|RequestMapping|Controller|RestController)\([^)]*\)"
    ]
}

jersey = {
    "language": "java",
    "name": "Jersey",
    "suffix": ".java",
    "regex": [
        r'@(Path|GET|POST|PUT|DELETE|HEAD|OPTIONS)\([^)]*\)'
    ]
}

asp_dotnet_core = {
    "language": "csharp",
    "name": "ASP DoNet Core",
    "suffix": ".cs",
    "regex": [
        r"(HttpGet|HttpPost|HttpPut|HttpPatch|HttpDelete)\b"
    ]
}

flask = {
    "language": "python",
    "name": "Flask",
    "suffix": ".py",
    "regex": [
        r'@app\.(route|get|post|put|delete|patch)\([\'"][^\'"]+[\'"]\)\s*\n\s*def\s+\w+\(.*?\):'
    ]
}

django = {
    "language": "python",
    "name": "Django",
    "suffix": ".py"
}

web_py = {
    "language": "python",
    "name": "Web Py",
    "suffix": ".py"
}

tornado = {
    "language": "python",
    "name": "Tornado",
    "suffix": ".py"
}

projects = [
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\digdag\digdag-server",
        "short_name": "Digdag"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\enviroCar-server",
        "short_name": "enviroCar"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\features-service",
        "short_name": "Features-Service"
    },
    {
        "framework": jersey,
        "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\gravitee-api-management\gravitee-apim-rest-api",
        "short_name": "Gravitee"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\kafka-rest", "short_name": "Kafka"
    },
    {
        "framework": jersey,
        "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\management-api-for-apache-cassandra",
        "short_name": "Cassandra"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\restcountries",
        "short_name": "RestCountries"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\senzing-api-server",
        "short_name": "Senzing"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\catwatch",
        "short_name": "CatWatch"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\cwa-verification-server",
        "short_name": "CWA"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\ocvn", "short_name": "OCVN"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\ohsome-api",
        "short_name": "Ohsome"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\proxyprint-kitchen",
        "short_name": "ProxyPrint"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\quartz-manager",
        "short_name": "Quartz"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\Ur-Codebin-API",
        "short_name": "Ur-Codebin"
    },
    {
        "framework": django, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\pokeapi-master",
        "short_name": "Poke",
        "configuration_file": r"D:\Researches\ReSpecLLM\datasets\datasets\pokeapi-master\pokemon_v2\urls.py"
    },
    {
        "framework": flask, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\gramps-web-api-master",
        "short_name": "Gramps",
        "configuration_file": r"D:\Researches\ReSpecLLM\datasets\datasets\gramps-web-api-master\gramps_webapi\api\__init__.py"
    },
    {
        "framework": tornado, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\jupyter_server-main",
        "short_name": "Jupyter",
        "keyword": r'default_handlers = ['
    },
    {
        "framework": web_py, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\mlmmjadmin-master",
        "short_name": "Mlmmj",
        "configuration_file": r"D:\Researches\ReSpecLLM\datasets\datasets\mlmmjadmin-master\controllers\urls.py",
        "urls": [
            # Profile
            '/api/(%s)$' % 'email', 'controllers.profile.Profile',

            # Owners.
            '/api/(%s)/owners' % 'email', 'controllers.profile.Owners',

            # Moderators.
            '/api/(%s)/moderators' % 'email', 'controllers.profile.Moderators',

            #
            # Per-maillist subscribers
            #
            # Get subscribers.
            '/api/(%s)/subscribers' % 'email', 'controllers.subscriber.Subscribers',

            # Check whether given subscriber is member of given mailing list.
            '/api/(%s)/has_subscriber/(%s)' % ('email', 'email'), 'controllers.subscriber.HasSubscriber',

            #
            # per-subscriber
            #
            # Get all subscribed mailing lists of given subscriber.
            '/api/subscriber/(%s)/subscribed' % 'email', 'controllers.subscriber.SubscribedLists',
            # Subscribe one subscriber to multiple mailing lists.
            '/api/subscriber/(%s)/subscribe' % 'email', 'controllers.subscriber.Subscribe',
        ]
    },
    {
        "framework": asp_dotnet_core, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\bitwarden-server-main\src",
        "short_name": "Bitwarden"
    }
]

print(f'projects: {len(projects)}')


def format_folder_name(path):
    folder_name = os.path.basename(os.path.normpath(path))
    folder_name_lower = folder_name.lower()
    formatted_name = folder_name_lower.replace(' ', '-')
    return formatted_name
