import os

spring_boot = {
    "language": "java",
    "suffix": ".java",
    "regex": [
        r"@(GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|RequestMapping|Controller|RestController)\([^)]*\)"
    ]
}

jersey = {
    "language": "java",
    "suffix": ".java",
    "regex": [
        r'@(Path|GET|POST|PUT|DELETE|HEAD|OPTIONS)\([^)]*\)'
    ]
}

asp_dotnet_core = {
    "language": "csharp",
    "suffix": ".cs",
    "regex": [
        r"(HttpGet|HttpPost|HttpPut|HttpPatch|HttpDelete)\b"
    ]
}

flask = {
    "language": "python",
    "suffix": ".py",
    "regex": [
        r'@app\.(route|get|post|put|delete|patch)\([\'"][^\'"]+[\'"]\)\s*\n\s*def\s+\w+\(.*?\):'
    ]
}

django = {
    "language": "python",
    "suffix": ".py",
    "regex": [
        r'urlpatterns\s*=\s*\[[^\]]*(path\([\'"]([^\'"]+)[\'"],\s*([^,]+)\)|re_path\([\'"]([^\'"]+)[\'"],\s*([^,]+)\))[^\]]*\]'
    ],
    "configuration_files": [
        "urls.py"
    ]
}

web_py = {
    "language": "python",
    "suffix": ".py",
    "regex": [
        r'urlpatterns\s*=\s*\[[^\]]*(path\([\'"]([^\'"]+)[\'"],\s*([^,]+)\)|re_path\([\'"]([^\'"]+)[\'"],\s*([^,]+)\))[^\]]*\]'
    ],
    "configuration_files": [
        "urls.py"
    ]
}

projects = [
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\digdag\digdag-server",
        "short_name": "Digdag"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\enviroCar-server",
        "short_name": "enviroCar"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\features-service",
        "short_name": "Features-Service"
    },
    {
        "framework": jersey,
        "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\gravitee-api-management\gravitee-apim-rest-api",
        "short_name": "Gravitee"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\kafka-rest", "short_name": "Kafka"
    },
    {
        "framework": jersey,
        "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\management-api-for-apache-cassandra",
        "short_name": "Cassandra"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\restcountries",
        "short_name": "RestCountries"
    },
    {
        "framework": jersey, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\senzing-api-server",
        "short_name": "Senzing"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\catwatch",
        "short_name": "CatWatch"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\cwa-verification-server",
        "short_name": "CWA"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\ocvn", "short_name": "OCVN"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\ohsome-api",
        "short_name": "Ohsome"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\proxyprint-kitchen",
        "short_name": "ProxyPrint"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\quartz-manager",
        "short_name": "Quartz"
    },
    {
        "framework": spring_boot, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\Ur-Codebin-API",
        "short_name": "Ur-Codebin"
    },
    {
        "framework": flask, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\pokeapi-master",
        "short_name": "Poke"
    },
    {
        "framework": flask, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\gramps-web-api-master",
        "short_name": "Gramps"
    },
    {
        "framework": django, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\jupyter_server-main",
        "short_name": "Jupyter"
    },
    {
        "framework": web_py, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\mlmmjadmin-master",
        "short_name": "Mlmmj"
    },
    {
        "framework": asp_dotnet_core, "root_path": r"D:\Researches\ReSpecLLM\datasets\datasets\bitwarden-server-main",
        "short_name": "Bitwarden"
    }
]

print(f'projects: {len(projects)}')


def format_folder_name(path):
    # 获取路径中的最后一个文件夹名称
    folder_name = os.path.basename(os.path.normpath(path))
    # 将文件夹名称转换为小写
    folder_name_lower = folder_name.lower()
    # 将空格替换为连字符
    formatted_name = folder_name_lower.replace(' ', '-')
    return formatted_name
