import os


def find_controller_files(urls, controllers_dir):
    def match_controller_files(controller):
        # 去掉类名，提取模块名
        module_name = controller.split('.')[:-1]  # 去掉最后一个元素，即类名
        module_path = os.path.join(*module_name) + '.py'  # 把模块名拼接成路径
        matched_files = []

        # 遍历指定目录中的所有文件
        for root, _, files in os.walk(controllers_dir):
            for file in files:
                if file == os.path.basename(module_path):
                    matched_files.append(os.path.join(root, file))

        return matched_files

    found_files = []

    for i in range(1, len(urls), 2):  # 每对元素中只关注第二个元素，即控制器
        controller = urls[i]
        matched = match_controller_files(controller)
        found_files.extend(matched)  # 添加找到的文件
    return set(found_files)
