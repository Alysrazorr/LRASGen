from datetime import datetime

from methodology import step1, step2, step3, step4, step5
from methodology.projects import projects, format_folder_name

if __name__ == '__main__':
    project = projects[0]
    project_root_path = project['root_path']
    project_framework = project['framework']

    timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    task_id = format_folder_name(project_root_path + '__' + timestamp)
    print(task_id)

    begin_time = datetime.now()

    # step1: filter endpoint files
    endpoint_entry_files = step1.main(project)

    if len(endpoint_entry_files) > 0:
        # step2: extract related code files
        endpoint_code_files = step2.main(endpoint_entry_files, project)

        if len(endpoint_code_files) > 0:
            pass
            # step3: analyze endpoints
            endpoint_information = step3.main(endpoint_code_files, task_id)

            # step4: analyze endpoint details (parameters, return schemas, exceptions...)
            step4.main(endpoint_information, endpoint_code_files, task_id)

            # step5: generate oas
            step5.main(task_id)
        # else:
        print('no endpoints files.')

    print(f"execution time: {datetime.now() - begin_time}")
