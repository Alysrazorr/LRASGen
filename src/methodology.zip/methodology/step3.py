import json

from utils.db_utils import insert_into_mysql
from utils.llm_utils import send_msg
from utils.str_utils import get_prompt

json_schema = [{
    "endpoint_path": "the uri path of this endpoint, such as: /api/getUser/:id/{:name}",
    "http_method": "http method type, such as: GET, POST, DELETE...",
    "method_name": "endpoint method name, such as: getUser()",
    "summary": "the summary of this endpoint",
    "description": "the description of this endpoint"
}]


def main(endpoint_code_files, task_id):
    endpoint_information = {}

    for entry_file_path, related_codes in endpoint_code_files.items():
        print(
            f"Endpoint entry file: {entry_file_path}, count of related code files: {len(endpoint_code_files.items())}")

        codes = make_code_files(entry_file_path, related_codes)

        endpoints = handle_endpoints(entry_file_path, codes, task_id)

        endpoint_information[entry_file_path] = endpoints

    return endpoint_information


def handle_endpoints(entry_file_path, codes, task_id):
    prompt = get_prompt('step3_1') % (codes, json_schema)

    re = send_msg([{"role": "user", "content": prompt}])

    re_json = json.loads(re.choices[0].message.content)

    endpoints = re_json.get('endpoints', [])

    _endpoints = []

    for endpoint in endpoints:
        _endpoints.append({
            "task_id": task_id,
            "endpoint_name": f'{endpoint["http_method"]} "{endpoint["endpoint_path"]}"',
            "endpoint_operation_Id": f'{endpoint["http_method"]}__{str(endpoint["endpoint_path"]).replace("/", "_")}___{endpoint["method_name"]}',
            "endpoint_path": endpoint['endpoint_path'],
            "endpoint_method_name": endpoint['method_name'],
            "endpoint_http_method": endpoint['http_method'],
            "endpoint_description": endpoint.get('description', None),
            "endpoint_summary": endpoint.get('summary', None),
            "entry_code_file_path": entry_file_path
        })

    if len(_endpoints) > 0:
        insert_into_mysql("lrasgen_endpoints", _endpoints)
        return endpoints


def make_code_files(entry_file_path, related_codes):
    codes = f'Entry_code({entry_file_path}):\n<<<\n{related_codes["entry_code_file"]}\n>>>\n'
    for code in related_codes.items():
        if code[0] != 'entry_code_file':
            codes += f'\nRelated_code({code[0]}):\n<<<\n{code[1]}\n>>>\n'
    return codes
