import os
import re


def find_imports_in_file(filepath):
    imports = set()
    with open(filepath, 'r', encoding='utf-8') as file:
        for line in file:
            # 去掉注释
            line = re.sub(r'#.*$', '', line).strip()
            if not line:  # 跳过空行
                continue

            # 匹配 'import xxx' 和 'from xxx import *'
            import_match = re.match(r'import (.+)', line)
            from_import_match = re.match(r'from (.+) import \*\s*', line)

            if import_match:
                modules = import_match.group(1).split(',')
                for module in modules:
                    imports.add(module.strip())

            if from_import_match:
                # 仅添加 b.py 中的 b
                from_path = from_import_match.group(1).strip()
                module = from_path.split('.')[-1]  # 取最后一部分
                imports.add(module)

    return imports


def is_in_project_path(import_name, project_path):
    # 将点号替换为路径分隔符
    full_import_path = import_name.replace('.', os.path.sep)

    # 检查.py文件
    py_file_path = os.path.join(project_path, f"{full_import_path}.py")
    if os.path.isfile(py_file_path):
        return py_file_path

    # 检查目录（包）
    dir_path = os.path.join(project_path, full_import_path)
    if os.path.isdir(dir_path):
        return dir_path

    # 进一步检查是否为模块对应的路径
    parts = import_name.split('.')
    for i in range(len(parts)):
        module_path = os.path.join(project_path, *parts[:i + 1])
        if os.path.isfile(f"{module_path}.py"):
            return f"{module_path}.py"
        if os.path.isdir(module_path):
            return module_path

    return None  # 如果没有找到则返回None


def main(urls_filepath):
    project_root = os.path.dirname(os.path.abspath(urls_filepath))  # 获取项目根路径
    imports = find_imports_in_file(urls_filepath)

    file_paths = []

    for import_name in imports:
        file_path = is_in_project_path(import_name, project_root)
        if file_path:
            file_paths.append(file_path)  # 只添加路径，不添加模块名

    return file_paths


if __name__ == "__main__":
    urls_file = 'your_project/urls.py'  # 替换为你的 urls.py 路径
    import_paths = main(urls_file)

    print("导入的文件路径：")
    for path in import_paths:
        print(path)
