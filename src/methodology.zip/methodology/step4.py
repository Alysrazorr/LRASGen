import json

from methodology.step3 import make_code_files
from utils.db_utils import insert_into_mysql
from utils.llm_utils import send_msg
from utils.str_utils import get_prompt

json_schema_for_parameter = [
    {
        "name": "str_param",
        "type": "string",
        "require": "true",
        "position": "query",
        "description": "some string parameter",
        "max_length": "128",
        "min_length": "16",
        "dictionary": [{"key1": "value1", "key2": "value2"}],
        "enum": ["enum1", "enum2", "enum3"],
        "format": "yyyy-mm-dd hh24:mi:ss",
        "default_value": "hello world"
    }, {
        "name": "num_param",
        "type": "int",
        "require": "true",
        "position": "path",
        "description": "some number parameter",
        "min": 2,
        "max": 16,
        "default_value": 0
    }, {
        "name": "bool_param",
        "type": "boolean",
        "require": "true",
        "position": "query",
        "description": "some boolean parameter",
        "default_value": True
    }, {
        "name": "nested_param",
        "type": "NestedRequest",
        "require": "true",
        "position": "body",
        "description": "some nested parameter",
        "nested_parameters": [{
            "name": "str_param",
            "type": "string",
            "require": "true",
            "position": "query",
            "description": "some string parameter",
            "max_length": "128",
            "min_length": "16",
            "dictionary": [{"key1": "value1", "key2": "value2"}],
            "enum": ["enum1", "enum2", "enum3"],
            "format": "yyyy-mm-dd hh24:mi:ss",
            "default_value": "hello world"
        }, {
            "name": "num_param",
            "type": "int",
            "require": "true",
            "position": "path",
            "description": "some number parameter",
            "min": 2,
            "max": 16,
            "default_value": 0
        }, {
            "name": "bool_param",
            "type": "boolean",
            "require": "true",
            "position": "query",
            "description": "some boolean parameter",
            "default_value": True
        }]
    }
]

json_schema_for_response = [
    {
        "status_code": 200,
        "description": "some response",
        "data_schema": [
            {
                "name": "UserInfo",
                "schema": {
                    "username": "string",
                    "password": "string",
                    "birthday": "date",
                    "age": "integer",
                    "email": "string",
                    "is_vip": "boolean",
                    "expires": "long",
                }
            }
        ]
    },
    {
        "status_code": 500
    }
]


def handle_parameters(codes, endpoint_name, method_name, task_id):
    prompt = get_prompt('step4_1') % (
        codes,
        endpoint_name,
        method_name,
        json_schema_for_parameter
    )

    re = send_msg([{"role": "user", "content": prompt}])

    re_json = json.loads(re.choices[0].message.content)

    parameters = re_json.get('parameters', [])

    _parameters = []

    for parameter in parameters:
        nested_parameters = parameter.get('nested_parameters', None)
        if nested_parameters is not None:
            for nested_parameter in nested_parameters:
                fill_parameter(_parameters, nested_parameter, task_id, endpoint_name)
        else:
            fill_parameter(_parameters, parameter, task_id, endpoint_name)

    if len(_parameters) > 0:
        insert_into_mysql("lrasgen_parameters", _parameters)


def fill_parameter(ps, p, task_id, endpoint_name):
    ps.append({
        "task_id": task_id,
        "endpoint_name": endpoint_name,
        "parameter_name": p.get('name', None),
        "parameter_type": p.get('type', None),
        "parameter_position": p.get('position', None),
        "is_required": p.get('require', 'false'),
        "parameter_description": p.get('description', None),
        "min_value": p.get('min', None),
        "max_value": p.get('max', None),
        "min_length": p.get('min_length', None),
        "max_length": p.get('max_length', None),
        "default_value": p.get('default_value', None),
        "parameter_format": p.get('format', None),
        "parameter_dict": p.get('dictionary', None),
        "parameter_enum": p.get('enum', None),
    })


def handle_responses(codes, endpoint_name, method_name, task_id):
    prompt = get_prompt('step4_2') % (
        codes,
        endpoint_name,
        method_name,
        json_schema_for_response
    )

    re = send_msg([{"role": "user", "content": prompt}])

    re_json = json.loads(re.choices[0].message.content)

    responses = re_json.get('responses', [])

    _responses = []

    for response in responses:
        _responses.append({
            "task_id": task_id,
            "endpoint_name": endpoint_name,
            "status_code": response.get('status_code', None),
            "response_description": response.get('description', None),
            "data_schema": response.get('data_schema', [])
        })

    if len(_responses) > 0:
        insert_into_mysql("lrasgen_responses", _responses)


def main(endpoint_information, endpoint_code_files, task_id):
    if len(endpoint_information) == 0:
        return

    for entry_file_path, related_codes in endpoint_code_files.items():
        codes = make_code_files(entry_file_path, related_codes)
        endpoint_list = endpoint_information.get(entry_file_path, [])
        print(f'entry_file_path: {entry_file_path}, endpoint_list: {endpoint_list}')

        if endpoint_list is not None:
            for endpoint in endpoint_list:
                endpoint_name = f'{endpoint["http_method"]} "{endpoint["endpoint_path"]}"'
                method_name = endpoint['method_name']

                print(f'endpoint_name: {endpoint_name}, method_name: {method_name}')

                handle_parameters(codes, endpoint_name, method_name, task_id)
                handle_responses(codes, endpoint_name, method_name, task_id)
