from fuzzywuzzy import fuzz


def fuzzy_match(target_string, strings, threshold=80):
    """
    Performs fuzzy matching on a target string against a list of candidate strings.

    Args:
        target_string (str): The string to match.
        strings (list): The list of candidate strings to compare against.
        threshold (int, optional): The minimum similarity score for a match. Default is 80.

    Returns:
        list: A list of tuples containing matching strings and their similarity scores.
    """
    matched_strings = []
    for string in strings:
        similarity = fuzz.partial_ratio(target_string, string)
        if similarity >= threshold:
            matched_strings.append((string, similarity))
    return matched_strings


import os


def list_files(directory):
    files_list = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.cs'):
                files_list.append(os.path.join(root, file))
    return files_list


def read_using_lines(file_path):
    using_lines = []

    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            # 移除前后空白字符
            stripped_line = line.strip()
            # 检查是否是 using 行
            if stripped_line.startswith("using "):
                using_lines.append(stripped_line)

    return using_lines


def read_without_using_lines(file_path):
    using_lines = []

    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            # 移除前后空白字符
            stripped_line = line.strip()
            # 检查是否是 using 行
            if not stripped_line.startswith("using "):
                using_lines.append(stripped_line)

    return using_lines


def main(root_path, start_file):
    matched_files = []

    all_files = list_files(root_path)
    print(all_files)

    using_lines = read_using_lines(start_file)
    print(using_lines)

    for using_line in using_lines:
        # 匹配命名空间
        matched_namespace = fuzzy_match(using_line.replace('using ', ''), all_files)
        for match, score in matched_namespace:
            # print(using_line + ", Matched Namespace:" + f"{match} (Score: {score})")
            matched_files.append(match)

    return matched_files


# 调用函数
if __name__ == "__main__":
    root_path = r"D:\Researches\ReSpecLLM\datasets\datasets\bitwarden-server-main\src"  # 项目根目录
    start_file = r"D:\Researches\ReSpecLLM\datasets\datasets\bitwarden-server-main\src\Api\Public\Controllers\CollectionsController.cs"  # 指定的入口文件B

    all_files = list_files(root_path)
    print(all_files)

    using_lines = read_using_lines(start_file)
    print(using_lines)

    for using_line in using_lines:
        # 匹配命名空间
        matched_namespace = fuzzy_match(using_line.replace('using ', ''), all_files)
        print(using_line + ", Matched Namespace:")
        for match, score in matched_namespace:
            print(f"{match} (Score: {score})")
