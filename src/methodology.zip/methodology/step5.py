import json
from typing import Dict

from utils.db_utils import query
from utils.llm_utils import send_msg
from utils.str_utils import get_prompt


# def main(task_id):
#     logger = get_logger()
#     # 生成规范
#     spec = generate_openapi_spec(task_id)
#
#     # 保存为JSON文件
#     with open(f'../data/specs/{task_id}.json', 'w', encoding='utf-8') as f:
#         json.dump(spec, f, ensure_ascii=False, indent=2)
#
#     print("OpenAPI specification generated successfully!")


# oas_root = {
#     "info": {
#         "description": "...",
#         "title": "...",
#         "version": "1.0.0"
#     },
#     "openapi": "3.1.1",
#     "servers": [
#         {
#             "url": "https://api.example.com/v1"
#         }
#     ],
#     "paths": {},
#     "components": {},
#     "x-rsl-global-components": {},
#     "x-rsl-interdependencies": {}
# }


def main(task_id):
    print(f"Begin generation. Task id: {task_id}")

    endpoints = query(f"select * from lrasgen_endpoints where task_id = '{task_id}'")
    parameters = query(f"select * from lrasgen_parameters where task_id = '{task_id}'")
    responses = query(f"select * from lrasgen_responses where task_id = '{task_id}'")

    prompt = get_prompt('step5_1') % (endpoints, parameters, responses)

    re = send_msg([{"role": "user", "content": prompt}])
    openapi_spec = re.choices[0].message.content

    re_json = json.loads(openapi_spec)
    with open(f'../data/specs/{task_id}.json', 'w', encoding='utf-8') as f:
        json.dump(re_json, f, ensure_ascii=False, indent=2)


def generate_openapi_spec(task_id) -> Dict:
    """Generate OpenAPI v3.1.1 specification from database tables"""

    # 初始化基础OpenAPI结构
    openapi_spec = {
        "openapi": "3.1.1",
        "info": {
            "title": "API Specification",
            "version": "1.0.0"
        },
        "paths": {}
    }

    # 获取所有端点
    endpoints = query("SELECT * FROM respecllm.endpoints where task_id = '%s'" % (task_id,))

    # 获取所有参数
    parameters = query("SELECT * FROM respecllm.parameters where task_id = '%s'" % (task_id,))

    # 获取所有响应
    responses = query("SELECT * FROM respecllm.responses where task_id = '%s'" % (task_id,))

    # 按端点组织数据
    endpoint_map: Dict[str, Dict[str, Dict]] = {}

    for endpoint in endpoints:
        path = endpoint["endpoint_path"]
        method = endpoint["endpoint_http_method"].lower()
        operation_id = endpoint.get("endpoint_operation_Id") or endpoint["endpoint_method_name"]

        if path not in openapi_spec["paths"]:
            openapi_spec["paths"][path] = {}

        endpoint_map.setdefault(path, {}).setdefault(method, {
            "operationId": operation_id,
            "summary": endpoint.get("endpoint_summary"),
            "description": endpoint.get("endpoint_description"),
            "parameters": [],
            "responses": {}
        })

        # 添加参数
        endpoint_params = [
            p for p in parameters
            if p["endpoint_name"] == endpoint["endpoint_name"]
               and p["task_id"] == endpoint["task_id"]
        ]

        for param in endpoint_params:
            parameter_schema = {
                "type": param["parameter_type"],
                "description": param.get("parameter_description"),
                "format": param.get("parameter_format")
            }

            # 处理约束条件
            if param["min_value"]: parameter_schema["minimum"] = float(param["min_value"])
            if param["max_value"]: parameter_schema["maximum"] = float(param["max_value"])
            if param["min_length"]: parameter_schema["minLength"] = int(param["min_length"])
            if param["max_length"]: parameter_schema["maxLength"] = int(param["max_length"])
            if param["default_value"]: parameter_schema["default"] = param["default_value"]

            if param["parameter_enum"]:
                parameter_schema["enum"] = param["parameter_enum"].split(",")
            elif param["parameter_dict"]:
                parameter_schema.update(json.loads(param["parameter_dict"]))

            openapi_param = {
                "name": param["parameter_name"],
                "in": param["parameter_position"],
                "required": bool(param["is_required"]),
                "schema": parameter_schema
            }

            endpoint_map[path][method]["parameters"].append(openapi_param)

        # 添加响应
        endpoint_responses = [
            r for r in responses
            if r["endpoint_name"] == endpoint["endpoint_name"]
               and r["task_id"] == endpoint["task_id"]
        ]

        for response in endpoint_responses:
            try:
                schema = json.loads(response["data_schema"]) if response["data_schema"] else None
            except:
                schema = None

            response_entry = {
                "description": response["response_description"],
                "content": {
                    "application/json": {
                        "schema": schema
                    }
                } if schema else {}
            }

            endpoint_map[path][method]["responses"][response["status_code"]] = response_entry

    # 合并数据到规范中
    for path, methods in endpoint_map.items():
        for method, spec in methods.items():
            openapi_spec["paths"].setdefault(path, {})[method] = spec

    return openapi_spec


if __name__ == "__main__":
    main('management-api-for-apache-cassandra__20250309-132338')
