import ast
import os
from pathlib import Path


def find_imports(filename):
    """解析Python文件，返回所有引入的模块"""
    with open(filename, 'r', encoding='utf-8') as file:
        node = ast.parse(file.read(), filename=filename)

    imports = set()
    for n in ast.walk(node):
        if isinstance(n, ast.ImportFrom):
            if n.module:
                imports.add((n.module, n.level))  # 保存模块名和相对导入级别
        elif isinstance(n, ast.Import):
            for alias in n.names:
                imports.add((alias.name, 0))  # 绝对导入的level设为0

    return imports


def find_all_py_files(directory):
    """递归找到目录下的所有Python文件"""
    py_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".py"):
                py_files.append(Path(os.path.join(root, file)))
    return py_files


def resolve_imports(base_path, directory):
    """解析指定文件及其引入的文件"""
    imports = find_imports(base_path)
    resolved_files = {base_path}

    base_dir = base_path.parent
    all_py_files = find_all_py_files(directory)

    for module, level in imports:
        if level > 0:  # 处理相对导入
            target_dir = base_dir
            for _ in range(level - 1):
                target_dir = target_dir.parent  # 向上移动level-1次
            module_file = (target_dir / f"{module}.py").resolve()
        else:  # 绝对导入
            module_file = (Path(directory) / f"{module}.py").resolve()

        # 检查文件是否存在
        if module_file in all_py_files:
            resolved_files.add(module_file)
            resolved_files.update(resolve_imports(module_file, directory))

    return resolved_files


def main(directory_path, py_path):
    # 指定主文件
    main_file = Path(directory_path) / py_path
    if not main_file.exists():
        print(f"主文件 {main_file} 不存在！")
        return

    # 获取所有引入的Python文件
    all_imported_files = resolve_imports(main_file, directory_path)

    # 输出引入的文件
    print("找到的依赖文件：")
    for file in sorted(all_imported_files):
        print(file)

    return all_imported_files


def remove_imports_and_return_content(file_path):
    """
    读取Python文件内容，删除所有import行，并返回处理后的字符串

    参数:
        file_path (str): .py文件路径

    返回:
        str: 删除所有import行后的完整内容字符串
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # 过滤掉import行（保留非import行及原始格式）
    cleaned_lines = [
        line for line in lines
        if not (
            line.lstrip().startswith(('import ', 'from '))
        )
    ]

    # 拼接并返回结果字符串
    return ''.join(cleaned_lines)


if __name__ == '__main__':
    resolved_files = main()
    print(resolved_files)
