def find_http_endpoints(directory):
    matched_files = []
    """
    查找指定目录下所有 C# 文件中的 HTTP endpoints 定义

    :param directory: 要搜索的路径
    """
    # 定义正则表达式，匹配所有的 HTTP 方法
    pattern = re.compile(r'\[Http(Get|Post|Put|Delete|Patch|Options|Head)\]')

    # 遍历目录中的所有 .cs 文件
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.cs'):
                file_path = os.path.join(root, file)

                # 读取文件内容
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                    # 检查文件内容是否匹配正则表达式
                    if pattern.search(content):
                        print(f'Found endpoint definitions in: {file_path}')
                        matched_files.append(file_path)
    return matched_files


import os
import re


def find_cs_files(directory):
    """
    查找指定目录下所有 C# 文件，并返回文件路径列表

    :param directory: 要搜索的路径
    :return: C# 文件路径列表
    """
    cs_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.cs'):
                cs_files.append(os.path.join(root, file))
    return cs_files


def find_references(cs_file, cs_files):
    """
    找到指定 C# 文件中引用的其他 C# 文件

    :param cs_file: 要分析的 C# 文件路径
    :param cs_files: 所有 C# 文件的路径列表
    :return: 被引用的 C# 文件路径列表
    """
    references = []
    with open(cs_file, 'r', encoding='utf-8') as f:
        content = f.readlines()

    for line in content:
        match = re.match(r'\s*using\s+([a-zA-Z0-9_.]+);', line)
        if match:
            namespace = match.group(1)
            for file in cs_files:
                # 获取文件的名称（去掉路径和扩展名）
                file_name = os.path.splitext(os.path.basename(file))[0]
                # 检查文件名是否与命名空间匹配
                if file_name == namespace.split('.')[-1]:  # 检查是否相同
                    references.append(file)

    return references


def find_all_references(root_directory):
    """
    从根目录查找所有 C# 文件的引用

    :param root_directory: 根目录路径
    """
    cs_files = find_cs_files(root_directory)
    all_references = {}

    for cs_file in cs_files:
        references = find_references(cs_file, cs_files)
        all_references[cs_file] = references

    return all_references


# 调用函数
if __name__ == "__main__":
    path = r"D:\Researches\ReSpecLLM\datasets\datasets\bitwarden-server-main\src"  # 根据实际情况修改
    find_http_endpoints(path)
