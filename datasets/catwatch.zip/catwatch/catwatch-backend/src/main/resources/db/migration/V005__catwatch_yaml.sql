ALTER TABLE project ADD COLUMN title text;
ALTER TABLE project ADD COLUMN image text;

