ALTER TABLE project ADD COLUMN external_contributors_count integer;
ALTER TABLE statistics ADD COLUMN external_contributors_count integer;
