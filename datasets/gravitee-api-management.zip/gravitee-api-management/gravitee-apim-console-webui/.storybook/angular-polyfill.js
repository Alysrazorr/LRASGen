require('@angular/compiler');
