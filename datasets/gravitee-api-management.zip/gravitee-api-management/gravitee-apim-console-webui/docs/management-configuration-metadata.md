# Metadata

Metadata let you retrieve platform custom information. This metadata is intended for various use cases such as retrieving support email, manage dynamic documentation and configuration template  or managing customizations.

(+) button let you create a new metadata.
