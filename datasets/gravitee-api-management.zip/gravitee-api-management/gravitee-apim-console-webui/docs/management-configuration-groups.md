# Groups

A group entity represents an API or an application group of users. 
Each member of a group has roles to perform certain actions on an API or an application.

Users are fetched from identity providers configured at Management API level.

In addition, group can be created specific to an API or an application. 

(+) button let you create a new group.
