# Dashboard

Here you can organize your dashboard by moving and resizing the widgets.

You can also add and delete widgets to display the metrics you want/need.
