# Portal categories

Categories let you organize automatically into categories the APIs.
Categories allow to filter, sort, or group API to make them easier to find by the consumers.

Categories are visible on the APIs portal page only if one or more APIs belong to these categories.

You can create a new category by clicking on the *New category* input.
