# Client Registration

A client registration provider is an authorization server which is compliant with the Dynamic Client
Registration from OpenID Connect.

When a provider is created / updated, Gravitee.io is looking to the Discovery Metadata endpoint to get
the configuration of the Client Registration.
