# Gateways

Retrieve all your registered Gateway instances. By default, only started instances are visible.

You can display all (started and stopped) gateway instances by switching on the *display all instances* button.
