# Configure alerts

## Alerts

Configure your own alerts.

Be alerted by email when the HC status changed or when the quota reached a percent rate.

You can find examples in the Gravitee documentation to configure <a href="https://docs.gravitee.io/ae/apim_platform.html" target="blank">platform alerts</a> or <a href="https://docs.gravitee.io/ae/apim_api.html" target="blank">api alerts</a>
