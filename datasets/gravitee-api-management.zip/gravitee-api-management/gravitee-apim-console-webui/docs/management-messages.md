# Messages

You can send a message with email or portal notifications:
 - select the communication channel,
 - filter the recipient population by their roles,
 - fill the object and message,
 - send it !
