# Alerts

Here you can find global information and highlights of the API alerts.

The first graph provides the number of events by alert severity.

The second line gives you a quick view of alerts sorted by severity, then by decreasing number of events for the time-range selected. An alert appears only if an event has occurred during the time-range.
