# API History

Keep track of every API's changes per deployment. 
You can select each history's events and compare changes across time. 

In the event of an error during API configuration update, 
you have the possibility to roll back your configuration back to a previous stable state by clicking on the *ROLLBACK* button. 
