# Application General

Set general information about your application such as its name, its type (mobile/web) and description.
You can also give access to your application to registered groups.

If relevant, you can set the domain used by your application (for instance `https://my-app.com`). It will help API publishers to properly configure access controls.
TIP: You can set multiple domains separated by commas.
