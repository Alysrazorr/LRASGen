# Manage applications

Retrieve all your registered applications. You can click on each table's row to get application's information.

The (+) button let you create a new application.
