# Identity providers

By creating identity provider, you are providing capabilities to users to login into the portal / management-ui using 
external user accounts from GitHub, Google, OpenID Connect server or Gravitee.io AM.

You can add as many identity providers as you need and configure each of them individually to manage
groups and / or roles for users coming from a given identity provider.  
