# Dictionaries

Dictionaries let you manage global properties to gateway runtime.

These properties are then available to API publisher who are able to use them from their API configuration.
