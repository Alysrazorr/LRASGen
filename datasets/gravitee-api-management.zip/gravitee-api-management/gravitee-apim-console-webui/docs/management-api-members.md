# API Members

API members can be a user or group. Each member has roles to manage and perform certain tasks and operations in the API according to their role's permissions.

The (+) button let you create a new member with specific roles.
