# Gateway monitoring

Collect monitor information about the JVM, CPU, Process, Thread and Garbage collector. 
