# Endpoint discovery

Endpoint discovery is the automatic detection of services offered by a provider.

Discovered endpoints are automatically added / removed to / from the endpoints pool without overriding _manually defined_ endpoint(s).  
