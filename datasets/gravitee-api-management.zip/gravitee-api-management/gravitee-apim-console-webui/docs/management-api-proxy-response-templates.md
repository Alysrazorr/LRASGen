# Response templates

Response templates allow to override the default HTTP response when receiving an error from a policy.
 
