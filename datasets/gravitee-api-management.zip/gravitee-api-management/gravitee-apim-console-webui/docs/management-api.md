# API General

Set general information about your API such as its name, version, picture and description.
You can switch API visibility to restrict access to the API.

Portal section let you add some labels and categories to categorize your API and make it easier to find for the consumers.

*IMPORT* button will load and replace API data from the imported API definition.

*EXPORT* button will export your API as API definition json format to easily recreate your API for a different environment for example.
