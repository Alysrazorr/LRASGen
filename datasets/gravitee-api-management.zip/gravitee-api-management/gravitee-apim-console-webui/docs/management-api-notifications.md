# Configure your Notifications

## Portal Notifications

Configure your own notifications, displayed in the bell in the navigation bar.

## Other Notifications

Create a Notification configuration using a notifier (an email or a webhook).
In addition to the events to subscribe for, you also need to configure the notifier.