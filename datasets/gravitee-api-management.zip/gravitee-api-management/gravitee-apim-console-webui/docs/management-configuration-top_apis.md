# Portal top APIs

Top APIs are visible into the APIs portal home page only if one or more APIs belong to these categories.

There is no limit and an API can be added more than once.

You can create a new top API by clicking on the *+* button.
