# Create application

An application is required to subscribe to API's plan. It is the intermediate link between a user (you) and an API
managed by someone else.


An application is a simple entity composed of small property which are mainly defined to describe the application
, what is does, ...

If relevant, you can set the domain used by your application (for instance `https://my-app.com`). It will help API publishers to properly configure access controls.
TIP: You can set multiple domains separated by commas.
