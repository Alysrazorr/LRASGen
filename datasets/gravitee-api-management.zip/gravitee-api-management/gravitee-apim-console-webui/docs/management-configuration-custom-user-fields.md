# Custom User Fields

A Custom User Field is an additional piece of information asked the user on the registration screen.

*Note*: Email address, Firstname and Lastname are available by default on the registration form.
