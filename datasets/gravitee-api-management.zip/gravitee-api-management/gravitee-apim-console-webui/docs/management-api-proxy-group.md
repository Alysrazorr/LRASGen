# Endpoints group

Group allows to manage a pool of endpoints. The group reference may be used while applying routing policy.
