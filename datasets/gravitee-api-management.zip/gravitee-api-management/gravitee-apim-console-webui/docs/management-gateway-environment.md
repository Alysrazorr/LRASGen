# Gateway environment

Retrieve instance information such as distribution information, deployed plugins list and system properties.
