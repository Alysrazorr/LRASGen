# Application Metadata

Application metadata let you retrieve custom information about your application and not the data itself (like name, version, etc ...).
These metadata are intended for various use cases such as retrieving support email, manage dynamic documentation and configuration template or managing customizations.

(+) button let you create a new metadata.
