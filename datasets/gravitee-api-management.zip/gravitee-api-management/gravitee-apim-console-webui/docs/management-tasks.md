# Tasks

The list of tasks requesting your attention.

Click on a task to be redirected to the page where you'll can handle it.