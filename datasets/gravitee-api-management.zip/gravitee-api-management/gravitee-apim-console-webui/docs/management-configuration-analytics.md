# Analytics

## Settings

You can manage analytics settings.

## Dashboards

Here you are able to manage the dashboards you want to display.

You can manage finely the dashboards to display on APIs, applications or on the platform.

You can add, delete, edit/reorder or enabled/disable dashboards and configure the widgets you want to display on each.
