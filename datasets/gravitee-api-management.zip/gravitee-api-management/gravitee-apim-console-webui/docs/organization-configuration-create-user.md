# User creation

Fill user information and validate. The new user will receive an email to finalize the creation by setting a password.

In case of a service account creation, email is not mandatory.
