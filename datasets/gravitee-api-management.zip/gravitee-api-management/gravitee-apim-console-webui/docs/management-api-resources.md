# API Resources

Resources are link to the API lifecycle. They are initialized when the API is starting and released when API is stopped.
Resources are used via the API policies to enhance API behavior.

Different resource types are available:

* Cache

Used to store re-usable data to avoid subsequent calls.

* OAuth 2.0

Used to introspect an access_token via an external OAuth 2.0 authorization server.

The (+) button let you create a new resource.
