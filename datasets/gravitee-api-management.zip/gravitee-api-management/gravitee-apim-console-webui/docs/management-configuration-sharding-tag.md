# Sharding tag

Configuration of the sharding tag.
It can be restricted to some groups to only allow users of these groups to deploy on this tag.
