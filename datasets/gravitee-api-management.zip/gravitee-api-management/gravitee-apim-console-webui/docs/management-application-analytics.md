# Application Analytics

Analytics collect and report application interactions with the APIs. 
Many metrics are available and can be filtered for a specific period of time and specific APIs.

*VIEW LOGS* button let you see a condensed view of the API calls made by the application.
