# API Endpoints

Configure Http client options, like timeout, SSL, proxy and health check service.
