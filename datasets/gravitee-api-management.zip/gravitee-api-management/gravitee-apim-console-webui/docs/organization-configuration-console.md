# Console Settings

Be careful before updating values, they will be automatically available on every new user session.

For example, you are able to select the Theme to apply on the console or toggle features like Support or Rating

Some settings are read-only because they are set with environment variables.
