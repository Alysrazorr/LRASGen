# Entry point

Add a configuration of an entry point to associate to a list of tags. This mapping will be used on the portal to display different entry points depending on API tags.
