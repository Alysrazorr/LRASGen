# Dashboard

Here you can find global information and highlights of the platform.

On the first line, you will find information about the state of the platform.

The second line of widgets and the API events table are dedicated to the main stats for the time range selected.
