# Users

Display all users that have an account on Gravitee.io.

Removing a user only remove its datas.
If your authentication mechanism allows him to reauthenticate on Gravitee.io, he will be allowed to connect and create a new account.
