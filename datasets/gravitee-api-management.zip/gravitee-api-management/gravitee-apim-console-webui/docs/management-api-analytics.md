# API Analytics

Analytics collect and report application interactions with the API. 
Many metrics are available and can be filtered for a specific period of time and specific applications.

*VIEW LOGS* button let you see a condensed view of the API calls.
