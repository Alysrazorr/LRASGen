.. _faq:


Frequently asked questions
==========================

Here is a list of questions we think you might have. This list will always be growing, so please feel free to add your question+anwer to this page! |:rocket:|


Can I configure multiple extensions at once?
--------------------------------------------

Checkout our "Operator" docs on how to :ref:`configure extensions <configure-multiple-extensions>`. |:closed_book:|
