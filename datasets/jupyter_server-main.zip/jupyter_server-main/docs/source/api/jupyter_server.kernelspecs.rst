jupyter\_server.kernelspecs package
===================================

Submodules
----------


.. automodule:: jupyter_server.kernelspecs.handlers
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jupyter_server.kernelspecs
   :members:
   :undoc-members:
   :show-inheritance:
