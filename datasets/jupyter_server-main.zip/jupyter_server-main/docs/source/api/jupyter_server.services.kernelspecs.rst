jupyter\_server.services.kernelspecs package
============================================

Submodules
----------


.. automodule:: jupyter_server.services.kernelspecs.handlers
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jupyter_server.services.kernelspecs
   :members:
   :undoc-members:
   :show-inheritance:
