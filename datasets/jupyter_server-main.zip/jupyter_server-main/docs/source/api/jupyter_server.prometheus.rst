jupyter\_server.prometheus package
==================================

Submodules
----------


.. automodule:: jupyter_server.prometheus.log_functions
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: jupyter_server.prometheus.metrics
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jupyter_server.prometheus
   :members:
   :undoc-members:
   :show-inheritance:
