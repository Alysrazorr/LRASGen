jupyter\_server.services package
================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jupyter_server.services.api
   jupyter_server.services.config
   jupyter_server.services.contents
   jupyter_server.services.events
   jupyter_server.services.kernels
   jupyter_server.services.kernelspecs
   jupyter_server.services.nbconvert
   jupyter_server.services.security
   jupyter_server.services.sessions

Submodules
----------


.. automodule:: jupyter_server.services.shutdown
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jupyter_server.services
   :members:
   :undoc-members:
   :show-inheritance:
