Documentation for Contributors
------------------------------

These pages target people who are interested in contributing directly to the Jupyter Server Project.

.. toctree::
   :caption: Contributors
   :maxdepth: 1
   :name: contributors

   team-meetings
   contributing
