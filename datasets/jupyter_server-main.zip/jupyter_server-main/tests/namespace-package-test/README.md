Blank namespace package for use in testing.

https://www.python.org/dev/peps/pep-0420/
