function main() {
  let div = document.getElementById("mydiv");
  div.innerText = "Hello from Typescript";
}

window.addEventListener("load", main);
