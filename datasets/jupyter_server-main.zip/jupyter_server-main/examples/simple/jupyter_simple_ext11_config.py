"""Jupyter server config."""

c.SimpleApp11.ignore_js = True  # type:ignore[name-defined]
