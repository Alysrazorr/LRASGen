"""Application cli main."""

from .application import main

if __name__ == "__main__":
    main()
