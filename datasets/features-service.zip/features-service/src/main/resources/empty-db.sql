delete from Constraint_Excludes;
delete from Constraint_Requires;
delete from Product_Configuration_Actived_Features;
delete from Product_Configuration;
delete from Feature;
delete from Product;

