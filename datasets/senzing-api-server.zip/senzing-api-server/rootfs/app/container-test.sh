#!/usr/bin/env bash

# Return codes.

OK=0
NOT_OK=1

# Tests.

echo "Doing testing."

exit ${OK}
