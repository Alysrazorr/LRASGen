package org.devgateway.ocvn.persistence.mongo.repository.shadow;

import org.devgateway.ocvn.persistence.mongo.repository.main.OrgGroupRepository;


public interface ShadowOrgGroupRepository extends OrgGroupRepository {

}
