package org.devgateway.ocvn.persistence.mongo.repository.shadow;

import org.devgateway.ocvn.persistence.mongo.repository.main.VNLocationRepository;

public interface ShadowVNLocationRepository extends VNLocationRepository {

}
