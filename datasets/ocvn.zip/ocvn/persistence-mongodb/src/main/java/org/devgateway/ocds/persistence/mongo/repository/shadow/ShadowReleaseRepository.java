/**
 * 
 */
package org.devgateway.ocds.persistence.mongo.repository.shadow;

import org.devgateway.ocds.persistence.mongo.repository.main.ReleaseRepository;

/**
 * @author mpostelnicu
 *
 */
public interface ShadowReleaseRepository extends ReleaseRepository {

}
