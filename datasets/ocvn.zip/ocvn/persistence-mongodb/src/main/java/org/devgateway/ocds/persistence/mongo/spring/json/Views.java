package org.devgateway.ocds.persistence.mongo.spring.json;

public class Views {
    public static class Public {
    }
    public static class Internal {
    }

}