/**
 *
 */
package org.devgateway.ocds.persistence.mongo.repository.shadow;

import org.devgateway.ocds.persistence.mongo.repository.main.VNOrganizationRepository;

/**
 * @author mpostelnicu
 *
 */
public interface ShadowVNOrganizationRepository extends VNOrganizationRepository {

}
