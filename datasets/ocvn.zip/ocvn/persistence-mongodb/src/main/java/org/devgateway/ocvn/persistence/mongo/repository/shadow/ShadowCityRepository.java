package org.devgateway.ocvn.persistence.mongo.repository.shadow;

import org.devgateway.ocvn.persistence.mongo.repository.main.CityRepository;

public interface ShadowCityRepository extends CityRepository {

}
