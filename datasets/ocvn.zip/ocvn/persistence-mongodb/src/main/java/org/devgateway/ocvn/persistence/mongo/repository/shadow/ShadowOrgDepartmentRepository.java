package org.devgateway.ocvn.persistence.mongo.repository.shadow;

import org.devgateway.ocvn.persistence.mongo.repository.main.OrgDepartmentRepository;

public interface ShadowOrgDepartmentRepository extends OrgDepartmentRepository {


}
