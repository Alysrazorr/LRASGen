package org.devgateway.ocds.persistence.mongo.repository.shadow;

import org.devgateway.ocds.persistence.mongo.repository.main.RecordRepository;

public interface ShadowRecordRepository extends RecordRepository {

}
