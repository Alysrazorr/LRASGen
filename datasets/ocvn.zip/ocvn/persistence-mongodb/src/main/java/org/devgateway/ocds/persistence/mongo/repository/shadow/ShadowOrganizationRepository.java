/**
 *
 */
package org.devgateway.ocds.persistence.mongo.repository.shadow;

import org.devgateway.ocds.persistence.mongo.repository.main.OrganizationRepository;

/**
 * @author mpostelnicu
 *
 */
public interface ShadowOrganizationRepository extends OrganizationRepository {

}
