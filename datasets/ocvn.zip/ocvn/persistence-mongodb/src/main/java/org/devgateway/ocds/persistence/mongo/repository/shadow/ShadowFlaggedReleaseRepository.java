/**
 * 
 */
package org.devgateway.ocds.persistence.mongo.repository.shadow;

import org.devgateway.ocds.persistence.mongo.repository.main.FlaggedReleaseRepository;

/**
 * @author mpostelnicu
 *
 */
public interface ShadowFlaggedReleaseRepository extends FlaggedReleaseRepository {

}
