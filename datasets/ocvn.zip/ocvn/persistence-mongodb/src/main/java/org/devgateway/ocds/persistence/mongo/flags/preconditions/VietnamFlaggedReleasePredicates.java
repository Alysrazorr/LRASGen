/**
 * 
 */
package org.devgateway.ocds.persistence.mongo.flags.preconditions;

/**
 * @author mpostelnicu
 *
 */
public final class VietnamFlaggedReleasePredicates {

    private VietnamFlaggedReleasePredicates() {

    }

}
