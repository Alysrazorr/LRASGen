package org.devgateway.ocds.persistence.mongo.flags;

public enum FlagType {
        RIGGING,
        FRAUD,
        COLLUSION
    };