package org.devgateway.ocds.persistence.mongo.repository.shadow;

import org.devgateway.ocds.persistence.mongo.repository.main.ClassificationRepository;

public interface ShadowClassificationRepository extends ClassificationRepository {

}
