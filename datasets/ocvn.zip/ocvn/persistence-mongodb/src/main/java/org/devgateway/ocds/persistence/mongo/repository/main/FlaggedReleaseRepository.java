/**
 * 
 */
package org.devgateway.ocds.persistence.mongo.repository.main;

import org.devgateway.ocds.persistence.mongo.FlaggedRelease;

/**
 * @author mpostelnicu
 *
 */
public interface FlaggedReleaseRepository extends GenericReleaseRepository<FlaggedRelease> {

}
