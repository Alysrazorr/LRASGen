/**
 *
 */
package org.devgateway.ocds.persistence.mongo.repository.main;

import org.devgateway.ocvn.persistence.mongo.dao.VNOrganization;

/**
 * @author mpostelnicu
 *
 */
public interface VNOrganizationRepository extends GenericOrganizationRepository<VNOrganization> {

}
