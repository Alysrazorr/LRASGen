package org.devgateway.ocvn.persistence.mongo.repository.shadow;

import org.devgateway.ocvn.persistence.mongo.repository.main.ContrMethodRepository;

public interface ShadowContrMethodRepository extends ContrMethodRepository {


}
