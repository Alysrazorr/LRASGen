package org.devgateway.ocds.persistence.mongo.reader;

/**
 * Created by mpostelnicu on 6/23/17.
 */
public class ImportWarningRuntimeException extends RuntimeException {

    public ImportWarningRuntimeException(String var1) {
        super(var1);
    }
}
