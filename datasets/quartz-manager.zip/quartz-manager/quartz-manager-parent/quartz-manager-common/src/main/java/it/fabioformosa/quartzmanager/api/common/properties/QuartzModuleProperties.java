package it.fabioformosa.quartzmanager.api.common.properties;

import lombok.Data;
import lombok.Generated;

import java.util.Properties;

@Data
@Generated
public class QuartzModuleProperties {

    private Properties properties = new Properties();

}
