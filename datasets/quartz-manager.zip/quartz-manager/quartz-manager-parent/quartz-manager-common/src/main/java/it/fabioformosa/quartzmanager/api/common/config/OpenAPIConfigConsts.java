package it.fabioformosa.quartzmanager.api.common.config;

public class OpenAPIConfigConsts {

  private OpenAPIConfigConsts(){
  }
  public static final String QUARTZ_MANAGER_SEC_OAS_SCHEMA = "quartz-manager-auth";

}
