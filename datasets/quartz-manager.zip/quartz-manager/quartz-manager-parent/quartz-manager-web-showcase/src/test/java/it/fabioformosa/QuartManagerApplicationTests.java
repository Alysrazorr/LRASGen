package it.fabioformosa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.web.WebAppConfiguration;

@SpringBootTest(classes = QuartzManagerDemoApplication.class)
@WebAppConfiguration
class QuartManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
