package it.fabioformosa.quartzmanager.api;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("it.fabioformosa.quartzmanager")
@SpringBootConfiguration
public class QuartManagerApplicationTests {

}
