package it.fabioformosa.quartzmanager.api.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = {"it.fabioformosa.quartzmanager.api"})
@Configuration
public class QuartzManagerApiConfig {
}
