package it.fabioformosa.quartzmanager.api.enums;

public enum SchedulerStatus {
	RUNNING, STOPPED, PAUSED
}
