package it.fabioformosa.quartzmanager.api.security;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringApplicationTest {
}
