package it.fabioformosa.quartzmanager.api.security.helpers.impl;

import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

public class AuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {

}
