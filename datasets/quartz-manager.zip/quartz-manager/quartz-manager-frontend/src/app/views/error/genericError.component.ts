import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'qrzmng-generic-error',
  templateUrl: './genericError.component.html',
  styleUrls: ['./genericError.component.css']
})
export class GenericErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
