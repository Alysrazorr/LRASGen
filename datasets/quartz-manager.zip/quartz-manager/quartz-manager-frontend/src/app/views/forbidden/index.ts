export * from './forbidden.component';
