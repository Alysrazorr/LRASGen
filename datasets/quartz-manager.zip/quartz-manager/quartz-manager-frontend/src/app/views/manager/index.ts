export * from './manager.component';
