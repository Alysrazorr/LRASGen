export * from './trigger-list.component'
