export * from './simple-trigger-config.component';
export {SimpleTriggerCommand} from '../../model/simple-trigger.command';
