export class JobDetail {
  jobClassName: string;
  description: string;
}
