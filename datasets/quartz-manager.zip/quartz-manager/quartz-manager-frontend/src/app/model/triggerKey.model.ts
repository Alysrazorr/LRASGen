export class TriggerKey {
  name: string;
  group: string;

  constructor(name?: string, group?: string) {
    this.name = name;
    this.group = group;
  }
}
