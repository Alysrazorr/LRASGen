export class JobKeyModel {
    name: string;
    group: string;
}
