export default class TriggerFiredBundle {
  timesTriggered: number;
  repeatCount: number;
  finalFireTime: string;
  nextFireTime: string;
  previousFireTime: string;
  jobKey: string;
  jobClass: string;
  percentage: number;
}
