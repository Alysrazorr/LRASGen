﻿namespace Bit.Sso.Utilities;

public static class SamlPropertyKeys
{
    public const string ClaimFormat = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/format";
}
