﻿namespace Bit.Scim;

public class ScimSettings
{
}
