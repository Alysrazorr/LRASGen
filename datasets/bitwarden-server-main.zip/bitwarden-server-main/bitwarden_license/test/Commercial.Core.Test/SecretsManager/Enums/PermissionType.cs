﻿namespace Bit.Commercial.Core.Test.SecretsManager.Enums;

public enum PermissionType
{
    RunAsAdmin,
    RunAsUserWithPermission,
    RunAsServiceAccountWithPermission,
}
