﻿using Bit.Core.AdminConsole.Enums.Provider;

namespace Bit.Admin.AdminConsole.Models;

public class CreateProviderModel
{
    public ProviderType Type { get; set; }
}
