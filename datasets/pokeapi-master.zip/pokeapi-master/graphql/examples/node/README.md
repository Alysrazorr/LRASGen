# Node examples

## `pokemon.js`

Fetches info about Staryu using `node-fetch`.

```sh
npm i
node pokemon.js
```
