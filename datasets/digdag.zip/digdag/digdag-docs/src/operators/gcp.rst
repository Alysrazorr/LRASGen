Google Cloud Platform operators
==================================

.. toctree::
    :maxdepth: 1

    gcs_wait.md
    bq.md
    bq_ddl.md
    bq_extract.md
    bq_load.md

