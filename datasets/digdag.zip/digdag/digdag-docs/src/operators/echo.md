# echo>: Shows a message

**echo>** operator shows given message.


    +say_hello:
      echo>: Hello world!

## Options

* **echo>**: STRING

  The message to show.

