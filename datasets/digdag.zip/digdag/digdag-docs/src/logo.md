# Logo

Feel free to use these logos on your slides, blog posts, etc.!

## Square

<img src="_static/logo/logo-digdag-sq-tr.png" alt="logo" title="logo" width="30%" height="30%">

## Horizontal

<img src="_static/logo/logo-digdag-rec-tr.png" alt="logo" title="logo" width="30%" height="30%">

## Logo

<img src="_static/logo/dig-dag-logo-tr.png" alt="logo" title="logo" width="20%" height="20%">

## Links

- [Digdag.ai](_static/logo/dig-dag-logo-symbol.ai)
- [Full list of files](https://github.com/treasure-data/digdag/tree/master/digdag-docs/src/_static/logo)
