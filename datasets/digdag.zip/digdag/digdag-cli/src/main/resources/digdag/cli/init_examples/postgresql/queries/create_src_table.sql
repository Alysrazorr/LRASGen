CREATE TABLE IF NOT EXISTS example_access_logs (
    time INTEGER,
    path CHARACTER VARYING,
    code INTEGER,
    agent CHARACTER VARYING,
    method CHARACTER VARYING
)

