#!/bin/bash

echo "$@ said \"I'm using $(uname -a)\""
sleep 1
