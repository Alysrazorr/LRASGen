package io.digdag.core.crypto;

public class SecretCryptoException
        extends RuntimeException
{
    public SecretCryptoException(Throwable cause)
    {
        super(cause);
    }
}
