package io.digdag.core.queue;

import com.google.inject.Inject;
import com.google.common.base.Optional;
import io.digdag.spi.TaskRequest;
import io.digdag.spi.TaskQueueRequest;
import io.digdag.spi.TaskQueueServer;
import io.digdag.spi.TaskConflictException;
import io.digdag.spi.TaskNotFoundException;
import io.digdag.core.agent.AgentId;
import io.digdag.core.repository.ResourceNotFoundException;
import io.digdag.core.repository.ResourceConflictException;
import io.digdag.core.workflow.TaskQueueDispatcher;
import org.weakref.jmx.Managed;
import java.util.concurrent.atomic.AtomicLong;

public class QueueTaskQueueDispatcher
        implements TaskQueueDispatcher
{
    private final AtomicLong enqueueCount = new AtomicLong(0L);

    private final QueueSettingStoreManager queueManager;
    private final TaskQueueServer taskQueueServer;

    @Inject
    public QueueTaskQueueDispatcher(
            QueueSettingStoreManager queueManager,
            TaskQueueServerManager queueServerManager)
    {
        this.queueManager = queueManager;
        this.taskQueueServer = queueServerManager.getTaskQueueServer();
    }

    @Managed
    public long getEnqueueCount()
    {
        return enqueueCount.get();
    }

    @Override
    public void dispatch(int siteId, Optional<String> queueName, TaskQueueRequest request)
        throws ResourceNotFoundException, TaskConflictException
    {
        enqueueCount.incrementAndGet();

        if (queueName.isPresent()) {
            int queueId = queueManager.getQueueIdByName(siteId, queueName.get());
            taskQueueServer.enqueueQueueBoundTask(queueId, request);
        }
        else {
            taskQueueServer.enqueueDefaultQueueTask(siteId, request);
        }
    }

    @Override
    public void taskFinished(int siteId, String lockId, AgentId agentId)
        throws TaskConflictException, TaskNotFoundException
    {
        taskQueueServer.deleteTask(siteId, lockId, agentId.toString());
    }

    @Override
    public boolean deleteInconsistentTask(String lockId)
    {
        return taskQueueServer.forceDeleteTask(lockId);
    }
}
