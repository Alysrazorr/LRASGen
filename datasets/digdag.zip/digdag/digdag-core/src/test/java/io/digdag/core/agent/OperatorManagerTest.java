package io.digdag.core.agent;

import com.google.common.base.Optional;
import com.google.common.io.Resources;
import io.digdag.client.DigdagClient;
import io.digdag.client.config.Config;
import io.digdag.client.config.ConfigElement;
import io.digdag.client.config.ConfigFactory;
import io.digdag.client.config.ConfigUtils;
import io.digdag.core.Limits;
import io.digdag.core.workflow.OperatorTestingUtils;
import io.digdag.spi.ImmutableTaskRequest;
import io.digdag.spi.Operator;
import io.digdag.spi.OperatorFactory;
import io.digdag.spi.SecretStoreManager;
import io.digdag.spi.TaskExecutionException;
import io.digdag.spi.TaskRequest;
import io.digdag.spi.TaskResult;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.time.Instant;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.atMost;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class OperatorManagerTest
{
    private AgentConfig agentConfig = AgentConfig.defaultBuilder().build();
    private AgentId agentId = AgentId.of("dummy");
    @Mock TaskCallbackApi callback;
    private ConfigFactory cf = new ConfigFactory(DigdagClient.objectMapper());
    @Mock OperatorRegistry registry;
    @Mock SecretStoreManager secretStoreManager;
    private Limits limits = new Limits(cf.create());
    private Config simpleConfig = cf.fromJsonString("{\"echo>\":\"hello\"}");

    private OperatorManager operatorManager;

    @Before
    public void setUp()
    {
        ConfigEvalEngine evalEngine = new ConfigEvalEngine(ConfigUtils.newConfig());
        WorkspaceManager workspaceManager = new LocalWorkspaceManager();

        operatorManager = new OperatorManager(
                agentConfig, agentId, callback, workspaceManager, cf,
                evalEngine, registry, secretStoreManager, limits);
    }

    @Test
    public void testFilterConfigForLogging()
            throws IOException
    {
        Config src = cf.fromJsonString(Resources.toString(OperatorManagerTest.class.getResource("/io/digdag/core/agent/operator_manager/filter_config_src.json"), UTF_8));
        Config srcBackup = src.deepCopy();
        Config expectedConfig = cf.fromJsonString(Resources.toString(OperatorManagerTest.class.getResource("/io/digdag/core/agent/operator_manager/filter_config_expected.json"), UTF_8));

        Config filteredConfig = operatorManager.filterConfigForLogging(src);

        assertEquals(src, srcBackup); // src must not be modified
        assertEquals(expectedConfig.getKeys().size(), filteredConfig.getKeys().size());
        for (String k : expectedConfig.getKeys()) {
            assertEquals(expectedConfig.get(k, Object.class), filteredConfig.get(k, Object.class));
        }
    }

    @Test
    public void testRunWithHeartbeatWithSuccessTask()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig);

        TaskResult result = mock(TaskResult.class);
        OperatorManager om = spy(operatorManager);
        doReturn(result).when(om).callExecutor(any(), any(), any());
        om.runWithHeartbeat(taskRequest);
        verify(callback, times(1)).taskSucceeded(eq(taskRequest), any(), eq(result));
        verify(callback, times(0)).taskFailed(any(), any(), any());
        verify(callback, times(0)).retryTask(any(), any(), anyInt(), any(), any());
    }

    @Test
    public void testRunWithHeartbeatWithCancelRequestedTask()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig).withIsCancelRequested(true);

        OperatorManager om = spy(operatorManager);
        Operator op = mock(Operator.class);
        OperatorFactory of = mock(OperatorFactory.class);
        doReturn(of).when(registry).get(any(), any());
        doReturn(op).when(of).newOperator(any());
        om.runWithHeartbeat(taskRequest);
        verify(op, times(0)).run();
        verify(op, times(1)).cleanup(any(TaskRequest.class));
        verify(callback, times(0)).taskSucceeded(any(), any(), any());
        verify(callback, times(1)).taskFailed(eq(taskRequest), any(), any());
        verify(callback, times(0)).retryTask(any(), any(), anyInt(), any(), any());
    }

    @Test
    public void testRunWithHeartbeatWithFailedTask()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig);

        OperatorManager om = spy(operatorManager);
        doThrow(new TaskExecutionException("Zzz")).when(om).callExecutor(any(), any(), any());
        om.runWithHeartbeat(taskRequest);
        verify(callback, times(0)).taskSucceeded(any(), any(), any());
        verify(callback, times(1)).taskFailed(eq(taskRequest), any(), any());
        verify(callback, times(0)).retryTask(any(), any(), anyInt(), any(), any());
    }

    @Test
    public void testRunWithHeartbeatWithFailedTaskWithRetryableFailure()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig);

        OperatorManager om = spy(operatorManager);
        doThrow(TaskExecutionException.ofNextPolling(42, ConfigElement.empty()))
                .when(om)
                .callExecutor(any(), any(), any());
        om.runWithHeartbeat(taskRequest);
        verify(callback, times(0)).taskSucceeded(any(), any(), any());
        verify(callback, times(0)).taskFailed(any(), any(), any());
        verify(callback, times(1)).retryTask(eq(taskRequest), any(), eq(42), any(), any());
    }

    @Test
    public void testRunWithHeartbeatWithFailedTaskWithRuntimeException()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig);

        OperatorManager om = spy(operatorManager);
        doThrow(new RuntimeException("Zzz")).when(om).callExecutor(any(), any(), any());
        om.runWithHeartbeat(taskRequest);
        verify(callback, times(0)).taskSucceeded(any(), any(), any());
        verify(callback, times(1)).taskFailed(eq(taskRequest), any(), any());
        verify(callback, times(0)).retryTask(any(), any(), anyInt(), any(), any());
    }

    @Test
    public void testRunWithHeartbeatWithFailedTaskWithUnexpectedError()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig);

        OperatorManager om = spy(operatorManager);
        doThrow(new OutOfMemoryError("Zzz")).when(om).callExecutor(any(), any(), any());
        om.runWithHeartbeat(taskRequest);
        // In current implementation, OperatorManager does nothing and the task eventually will retried
        verify(callback, times(0)).taskSucceeded(any(), any(), any());
        verify(callback, times(0)).taskFailed(any(), any(), any());
        verify(callback, times(0)).retryTask(any(), any(), anyInt(), any(), any());
    }

    @Test
    public void testRunWithHeartbeatWithFailedTaskWithUnexpectedErrorButTheTaskShouldBeCanceled()
    {
        TaskRequest taskRequest = OperatorTestingUtils.newTaskRequest(simpleConfig)
                .withIsCancelRequested(true);

        OperatorManager om = spy(operatorManager);
        doThrow(new OutOfMemoryError("Zzz")).when(om).callExecutor(any(), any(), any());
        om.runWithHeartbeat(taskRequest);
        verify(callback, times(0)).taskSucceeded(any(), any(), any());
        verify(callback, times(1)).taskFailed(eq(taskRequest), any(), any());
        verify(callback, times(0)).retryTask(any(), any(), anyInt(), any(), any());
    }

    @Test
    public void testCheckTaskLogPrintable()
    {
        // First polling must be true
        ImmutableTaskRequest request = OperatorTestingUtils.newTaskRequest(simpleConfig)
                .withRetryCount(0);
        assertTrue(OperatorManager.checkTaskLogPrintable(request));
        request = request.withRetryCount(1);
        assertFalse(OperatorManager.checkTaskLogPrintable(request));

        // After 30 min from start, every 10 polling must be true
        request = request.withStartedAt(Optional.of(Instant.now().minusSeconds(60*30+1)));
        assertFalse(OperatorManager.checkTaskLogPrintable(request.withRetryCount(5)));
        assertFalse(OperatorManager.checkTaskLogPrintable(request.withRetryCount(6)));
        assertFalse(OperatorManager.checkTaskLogPrintable(request.withRetryCount(7)));
        assertFalse(OperatorManager.checkTaskLogPrintable(request.withRetryCount(8)));
        assertFalse(OperatorManager.checkTaskLogPrintable(request.withRetryCount(9)));
        assertTrue(OperatorManager.checkTaskLogPrintable(request.withRetryCount(10)));
    }
}
