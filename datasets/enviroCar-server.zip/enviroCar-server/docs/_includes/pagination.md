Query parameters:

| Name    | Type  | Default | Details
|---------|-------|---------|--------
| `limit` | `int` | `0`     | Limit the response to the `limit` newest users. A limit &le; 0 results in no limit.
