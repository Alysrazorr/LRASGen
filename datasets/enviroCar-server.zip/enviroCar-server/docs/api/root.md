---
layout: default
---

# /
This is the root resource.

### GET
Get the root resource.
#### Response Schema
{% include_schema root %}
#### Response Example
{% include_example root %}

### `/`
Get the root resource.

[root.json]:        https://github.com/enviroCar/enviroCar-server/blob/master/rest/src/main/resources/schema/root.json "root.json"

* Example [root.json] file:

